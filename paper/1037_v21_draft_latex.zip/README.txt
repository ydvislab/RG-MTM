论文 1037（PacificVis 2027 会议论文轨道）LaTeX 源文件，v21 草稿（2026-11-08 中午）
官方 VGTC 会议模板（vgtc_conference_latex-2024.02.14），单盲，作者信息已加入。

这是重写中的草稿，不是最终稿
  已完成：第 1 步（论文骨架：统一表述、下界移到方法前、公式精简）、第 2 步（正文结果图）。
  未完成：第 3 步（摘要、引言、相关工作重写，补引用）、第 4 步（实验按问题 Q1–Q4 重排）、
          补充材料同步（算法框、两张示意图移入）、全文数字核对。
  所以摘要和引言还是旧版文字；实验部分图的位置与文字顺序暂时不完全对应。

新的论文思路（一句话）
  把合并树地图的轴锚定到空间，位置上必然要付出代价；我们算出任何地图都逃不掉的这份代价，
  做出一个只比它多付一点的地图（AnchorMTM），并用它说明现有地图的大部分误差并不是这份代价。

结构
  1 引言（待重写）  2 相关工作（待重写）
  3 空间锚定的合并树地图：合并树与剖面；统一表述（Eq. 3）——TMTM、ST-MTM 是"合并误差为 0、
    没有参考项"的两个特例（表 1）；空间参照；冲突在哪（图 2）
  4 保住树的代价：三个与布局无关的下界（定理 1–3）；"树逼的 vs 画法选的"
  5 AnchorMTM：统一表述的一个实例，逼近下界（叶序、放置、重建）
  6 实验（待按 Q1 下界紧不紧 / Q2 现有方法误差有多少是树逼的 / Q3 是否更准、守预算 / Q4 预算买到什么 重排）
  7 讨论与局限  8 结论

与 v20 相比的主要改动
  * 编号公式 23 个 → 9 个；新增统一表述公式和方法族表（表 1）。
  * 新图 4：位置–拓扑平面（七个序列，含二维和三维，所有方法在同一平面上，灰色为不可达区）。
  * 新图 6：三维效果对比（Tangaroa、Cylinder；参考位置 / TMTM / ST-MTM / AnchorMTM ε=0、5%、20%）。
  * 新图 7：逐帧分布（三个二维 + 两个三维数据集，ε=0/2/5/10/20%）。
  * Ring 案例（原图 7 与 5.6 节）和两张参数表移到补充材料末尾（图 S8、表 S3–S4）。
  * 贡献改为三条短句。
  * 篇幅：正文 9 页（17.5 栏，上限 18 栏）+ 参考文献 1 页；补充材料 13 页。

文件
  main.tex、supplement.tex、refs.bib、vgtc.cls、abbrv-doi-narrow.bst、tables/、figures/
  新图同时有可编辑的 SVG（文字为文本）：figures/plane_compact.svg、volume_gallery.svg、budget_distribution_2d3d.svg

编译
  Overleaf（pdfLaTeX）：上传整个压缩包，主文件选 main.tex；补充材料把主文件切换为 supplement.tex。
  本地：pdflatex main && bibtex main && pdflatex main && pdflatex main

作者信息
  两份文件里 "E-mails: To be added." 和 "Corresponding author. E-mail: To be added." 要填。

新图的数据来源（都是已保存结果，没有新实验）
  * 图 4：早期七序列基准的下界与 AnchorMTM 前沿；TMTM/ST-MTM/OLO 取与参考更一致的镜像。
  * 图 6：AnchorMTM 位置由 frontier 管线重算，与存档结果及体数据预算扫描逐项一致；
    TMTM、ST-MTM 为仓库中按原文实现保存的锚点，同一特征。若要换成标量地图，需要
    output/current_method_parameter_sweep_20261029/{tangaroa,cylinder}/epsilon_*.npz（合作者机器上）。
  * 图 7：budget_tradeoff_20261105 的完整序列逐帧结果（平面）和 volume_per_frame_audit.csv（体数据）。
  作图脚本在仓库 paper/anchor_full/figure_drafts/（plane_fig.py compact、volume_gallery_fig.py、budget_distribution.py v21）。
