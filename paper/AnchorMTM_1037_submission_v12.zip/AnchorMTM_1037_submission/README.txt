AnchorMTM: Spatially Anchored Merge Tree Maps for Time-Varying Scalar Fields
PacificVis 2027 Conference Paper Track, submission ID 1037 (v12, 2026-11-06)

AnchorMTM_1037_paper.pdf        main paper (9 pages body + 2 pages references)
AnchorMTM_1037_supplement.pdf   supplementary material (18 pages)
latex/                          LaTeX sources: main.tex, supplement.tex, vgtc.cls,
                                abbrv-doi-narrow.bst, refs.bib, figures/, tables/

Build (from latex/): pdflatex main && bibtex main && pdflatex main && pdflatex main
(same for supplement), or upload latex/ to Overleaf. Tested with tectonic.
